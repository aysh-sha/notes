package com.ust.FreshToHome.tests;

import org.testng.annotations.Test;

import com.ust.FreshToHome.base.SetUp;
import com.ust.FreshToHome.pages.HomePage;
import com.ust.FreshToHome.pages.VIPPage;

public class VIPTest extends SetUp {
	HomePage homepage;
	VIPPage vp;
  @Test
  public void f() {
  }
}
