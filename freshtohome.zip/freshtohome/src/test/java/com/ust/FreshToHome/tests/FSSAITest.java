package com.ust.FreshToHome.tests;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import com.ust.FreshToHome.base.SetUp;
import com.ust.FreshToHome.pages.FSSAIPage;
import com.ust.FreshToHome.pages.HomePage;

public class FSSAITest extends SetUp{
	HomePage homepage;
	FSSAIPage fp;
	
  @Test(priority=0)
  public void loadHomePage() {
	  homepage = new HomePage(driver);
	  homepage.getHomePage();
	  homepage.enterLocation();
	  assertTrue(homepage.checkUrl(properties.getProperty("homePageUrl")),"Falied to load homepage");
	  
  }
  
  @Test(priority=1)
  public void checkFssai() {
	  fp=homepage.clickReadyToCook(homepage.productready);
	  fp = new FSSAIPage(driver);
	  fp.click(fp.cutlet);
	  assertTrue(fp.textContains(fp.fssainumber,properties.getProperty("Fssainumber")),"Failed to validate FSSAInumber");
  }
  
}
