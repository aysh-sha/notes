package com.ust.FreshToHome.tests;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import com.ust.FreshToHome.base.SetUp;
import com.ust.FreshToHome.pages.HomePage;
import com.ust.FreshToHome.pages.SocialMediaPage;

public class SocialMediaLinkTest extends SetUp {
	HomePage homepage;
	SocialMediaPage social = new SocialMediaPage(driver);

	@Test(priority = 0)
	public void loadHomePage() {
		homepage = new HomePage(driver);
		homepage.getHomePage();
		homepage.enterLocation();
		assertTrue(homepage.checkUrl(properties.getProperty("homePageUrl")), "Failed to load home page");

	}

	@Test(priority = 1)
	public void testFacebookLink() {
		social = homepage.clickSocialMediaLinks(homepage.facebookLink);

		homepage.windowTabHandle();
		waits(4000);
		assertTrue(social.urlContains(properties.getProperty("facebookResult")),"Failed to load Facebook page");
		homepage.closeWindowTab();
		homepage.windowTabHandlezero();
	}

	@Test(priority = 2)
	public void testTwitterLink() {
		social = homepage.clickSocialMediaLinks(homepage.twitterLink);
		homepage.windowTabHandle();
		waits(4000);
		assertTrue(social.urlContains(properties.getProperty("twitterResult")),"Failed to load Twitter page");
		homepage.closeWindowTab();
		homepage.windowTabHandlezero();

	}

	@Test(priority = 3)
	public void testInstagramLink() {
		social = homepage.clickSocialMediaLinks(homepage.instagramLink);
		homepage.windowTabHandle();
		waits(4000);
		assertTrue(social.urlContains(properties.getProperty("instagramResult")),"Failed to load Instagram page");
		homepage.closeWindowTab();
		homepage.windowTabHandlezero();
	}

	@Test(priority = 4)
	public void testYoutubeLink() {
		social = homepage.clickSocialMediaLinks(homepage.youtubeLink);
		homepage.windowTabHandle();
		waits(4000);
		assertTrue(social.urlContains(properties.getProperty("youtubeResult")),"Failed to load Youtube page");
		homepage.closeWindowTab();
		homepage.windowTabHandlezero();
	}

}
