package com.ust.FreshToHome.tests;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ust.FreshToHome.base.SetUp;
import com.ust.FreshToHome.pages.HomePage;
import com.ust.FreshToHome.pages.SearchPage;
import com.ust.FreshToHome.utils.ExcelDataReader;

public class SearchTest extends SetUp {
	HomePage hp;
	SearchPage sp;

	@Test(priority = 0)
	public void loadHomePage() throws InterruptedException {
		hp = new HomePage(driver);
		hp.getHomePage();
		hp.enterLocation();
		assertTrue(hp.checkUrl(properties.getProperty("homePageUrl")), "Failed to load home page");

	}

    
  @Test(priority = 1)
	public void nullSearch() throws InterruptedException { 
	    sp=hp.clickSearch(hp.Searchbutton);
	    assertTrue(sp.textContains(properties.getProperty("noresults"),sp.noresults));

	}
  

	@Test(priority = 2,dataProvider = "valid")
	public void validateSearch(String text) {
		hp.sendText(hp.Searchfeild, text);
		sp=hp.clickSearch(hp.Searchbutton);
		sp= new SearchPage(driver);
		assertTrue(sp.textContains(properties.getProperty("Searchresult"),sp.Searchresults));
		waits(2000);
		//driver.navigate().back();

	}
	
	@Test(priority = 3,dataProvider = "invalid")
	public void invalidSearch(String text) {
		hp.sendText(hp.Searchfeild, text);
		sp=hp.clickSearch(hp.Searchbutton);
		sp= new SearchPage(driver);
		assertTrue(sp.textContains(properties.getProperty("noresults"),sp.noresults));


	}

	@DataProvider(name = "valid")
	public String[][] input() throws IOException {

		String path = System.getProperty("user.dir") + "\\src\\test\\resources\\DataSource\\Data.xlsx";
		String Sheetname = "Sheet1";
		String[][] data = ExcelDataReader.readDataFromSheet(Sheetname, path);

		return data;

	}

	@DataProvider(name = "invalid")
	public String[][] input2() throws IOException {

		String path = System.getProperty("user.dir") + "\\src\\test\\resources\\DataSource\\Data.xlsx";
		String Sheetname = "Sheet2";
		String[][] data = ExcelDataReader.readDataFromSheet(Sheetname, path);

		return data;

	}

}