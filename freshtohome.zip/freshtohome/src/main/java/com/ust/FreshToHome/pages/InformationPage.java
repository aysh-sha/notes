package com.ust.FreshToHome.pages;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.FreshToHome.reusables.ReusableFunction;
import com.ust.FreshToHome.utils.ConfigReader;

public class InformationPage {
	public WebDriver driver;
	public Properties prop;
	ReusableFunction rf;
	
	public InformationPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
		prop= ConfigReader.getPropertyValue();
		rf= new ReusableFunction(driver);
	}
	
	@FindBy(css="div[class='std'] h1")
	public WebElement refundpolicytext;
	
	@FindBy(css="div[class='page-title'] h1")
	public WebElement sellerstext;
	
	public boolean textContains(WebElement el,String txt) {
		return rf.textContains(txt, el);
	}
	
	
	
	
	

}
