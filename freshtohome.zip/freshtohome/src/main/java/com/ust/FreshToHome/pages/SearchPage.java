package com.ust.FreshToHome.pages;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.FreshToHome.reusables.ReusableFunction;
import com.ust.FreshToHome.utils.ConfigReader;

public class SearchPage {
	public WebDriver driver;
	public Properties prop;
	public ReusableFunction rf;

	public SearchPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		prop = ConfigReader.getPropertyValue();
		rf = new ReusableFunction(driver);
	}

	@FindBy(css = "div.page-title")
	public WebElement Searchresults;

	@FindBy(css = "#products div > h1")
	public WebElement noresults;
	
	@FindBy(css=".availability > span")
	public WebElement outOfStock;
	
	@FindBy(css=".product-name:nth-child(1)")
	public WebElement outOfStockProduct;
	
	@FindBy(className = "btn-cart")
	public WebElement addToCartBtn;
			
	@FindBy(xpath="//h3[normalize-space()='Butter Chicken Samosa - Pack of 4 (140g to 160g)']")
	public WebElement butterchicken;
	
	@FindBy(css="div[class='short-description'] span:nth-child(2)")
	public WebElement spices;
	
	@FindBy(xpath="//b[normalize-space()='Ingredients:']")
	public WebElement ingredients;

	public void insertDetails(WebElement el, String txt) {
		el.clear();

		el.sendKeys(txt);

	}
	public boolean textContains(String txt,WebElement el) {
		return rf.textContains(txt, el);
	}

	public void click(WebElement element) {
		rf.clickElement(element);
	}
	
	public boolean isDisplayed(WebElement element) {
		return rf.isPresent(element);
	}
	
	public boolean isNotPresent(WebElement element) {
		return rf.isNotPresent(element);
	}
	
	

}
