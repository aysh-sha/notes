package step_definitions;

import static org.testng.Assert.assertEquals;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.ust.FreshToHome.pages.CheckOutPage;
import com.ust.FreshToHome.pages.HomePage;
import com.ust.FreshToHome.pages.ProductPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ClearCart {
	public WebDriver driver = Hooks.driver;
	public Properties properties = Hooks.properties;
	public HomePage homePage;
	public ProductPage productPage;
	public CheckOutPage checkOutPage;
	
	@Given("the user is in freshtohome homepage")
	public void the_user_is_in_the_freshtohome_homepage() throws InterruptedException {
		homePage = new HomePage(driver);
		homePage.getHomePage();
		homePage.enterLocation();
		
	}
	
	@Given("the user select a product")
	public void the_user_select_a_product() {
		productPage = homePage.clickProduct(homePage.product1);
	}
	
	@Given("add the product to the cart")
	public void add_the_product_to_the_cart() {
	   productPage.click(productPage.addToCartBtn);
	}
	
	@Given("proceeds to checkout page")
	public void proceeds_to_checkout_page() {
		productPage.click(productPage.menu_cart_icon);
		checkOutPage = productPage.clickMyCart();
	}
	
	@When("user click on the clear cart button")
	public void user_click_on_the_clear_cart_button() {
		checkOutPage.click(checkOutPage.empty_cart_button);
	}
	
	@Then("the empty cart message has to be displayed")
	public void the_empty_cart_message_has_to_be_displayed() {
		assertEquals(checkOutPage.getEmptyCartMsg(), checkOutPage.getCartMsg());
	}
}
