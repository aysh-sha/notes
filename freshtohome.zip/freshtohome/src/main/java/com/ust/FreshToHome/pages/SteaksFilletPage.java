package com.ust.FreshToHome.pages;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.FreshToHome.reusables.ReusableFunction;

public class SteaksFilletPage {
	public WebDriver driver;
	public Properties prop;
	ReusableFunction rf;
	
	public SteaksFilletPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
		rf = new ReusableFunction(driver);
	}
	
	@FindBy(css=".level-top[href='/ready-to-eat']")
	public WebElement readyToCookLink;
	
	@FindBy(css=".category-header")
	public WebElement validateResultofSteaksPage;
	
	
	public ReadyToCookPage clickReadyToCooklink(WebElement el) {
		rf.clickElement(el);
		return new ReadyToCookPage(driver);
	}
	public boolean textContains(WebElement el,String txt) {
		return rf.textContains(txt, el);
	}

}
