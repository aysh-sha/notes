package com.ust.FreshToHome.utils;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelDataReader {
	public static String[][] readDataFromSheet(String sheetName,String filepath) throws IOException {
        String excelFilePath = filepath;
        FileInputStream inputStream = new FileInputStream(excelFilePath);
        Workbook workbook = new XSSFWorkbook(inputStream);
        Sheet sheet = workbook.getSheet(sheetName);

        int rowCount = sheet.getLastRowNum()+1;
        int colCount = sheet.getRow(0).getLastCellNum();

        String[][] data = new String[rowCount][colCount];
        DataFormatter df=new DataFormatter();
		
		
		for(int i=0;i<rowCount;i++)
		{
			for(int j=0;j<colCount;j++)
			{
				data[i][j]=df.formatCellValue(sheet.getRow(i).getCell(j));
			}
			
		}
        workbook.close();
        inputStream.close();
        return data;
    }

}
