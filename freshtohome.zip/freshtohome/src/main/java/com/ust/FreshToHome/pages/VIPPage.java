package com.ust.FreshToHome.pages;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.ust.FreshToHome.reusables.ReusableFunction;

import io.cucumber.core.internal.com.fasterxml.jackson.databind.ObjectReader;

public class VIPPage {
	public WebDriver driver;
	public Properties prop;
	ReusableFunction rf;
	
	public VIPPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
		rf =  new ReusableFunction(driver);
	}
	
	
	

}
