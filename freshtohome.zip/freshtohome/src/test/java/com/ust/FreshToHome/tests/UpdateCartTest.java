package com.ust.FreshToHome.tests;

import static org.testng.Assert.assertEquals;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.FreshToHome.base.SetUp;
import com.ust.FreshToHome.pages.CheckOutPage;
import com.ust.FreshToHome.pages.HomePage;
import com.ust.FreshToHome.pages.ProductPage;
import com.ust.FreshToHome.reusables.ReusableFunction;
import com.ust.FreshToHome.utils.ExtentReportsListener;
@Listeners(ExtentReportsListener.class)
public class UpdateCartTest extends SetUp{
	HomePage homePage;
    ProductPage productpage;
    CheckOutPage checkOutPage;
    ReusableFunction reusableFunction;
  @Test(priority = 0)
  public void checkUpdateCartPage() 
  {
	  homePage = new HomePage(driver);
	  homePage.getHomePage();
	  homePage.enterLocation();
	  productpage = homePage.clickProduct(homePage.product1);
	  productpage.clickAddToCartBtn();
	  productpage.click(productpage.menu_cart_icon);
	  checkOutPage = productpage.clickMyCart();
	  assertEquals(checkOutPage.getExpectedUrl(),checkOutPage.getActualUrl()); 
	  
  }
  
  @Test(priority = 1)
  public void checkUpdateCart() throws InterruptedException {
	 assertTrue(checkOutPage.checkUpdateCart());
	 
  }
}
