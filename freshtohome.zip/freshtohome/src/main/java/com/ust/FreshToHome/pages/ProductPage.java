package com.ust.FreshToHome.pages;

import java.time.Duration;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.FreshToHome.reusables.ReusableFunction;
import com.ust.FreshToHome.utils.ConfigReader;

public class ProductPage {
	public WebDriver driver;
	public Properties prop;
	ReusableFunction rf;
	public ProductPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		prop = ConfigReader.getPropertyValue();
		rf = new ReusableFunction(driver);
	}
	
	@FindBy(xpath="//div[@id='products']/div/div/a/div/div/img")
	public WebElement seerfish;
	
	@FindBy(className = "btn-cart")
	public WebElement addToCartBtn;
	
	@FindBy(id="ajaxallct")
	public WebElement ajaxallct;
	
	@FindBy(xpath="//span[text()='Checkout']")
	public WebElement checkoutbtn;
	
	@FindBy(id="ajaxcartmsgc")
	public WebElement ajaxcartmsgc;
	
	@FindBy(css = ".menu-cart-icon")
	public WebElement menu_cart_icon;
	
	@FindBy(xpath="//button[@title='Go to Cart Page']")
	public WebElement mycart;
	
	@FindBy(id="coupon_code")
	public WebElement couponcode;
	
	@FindBy(xpath="//button[@title='Apply']")
	public WebElement apply;
			
	@FindBy(xpath="//p[@class='up']")
    public WebElement quantityincrease;
	
	@FindBy(css = " div.subtotal > span.price")
	public WebElement sub_total_price;
	
	@FindBy(className = "qty-control")
	public WebElement qty_control;
	
	@FindBy(id="qty")
	public WebElement quantity;
	@FindBy(css=".up")
	public WebElement plus;
	
	@FindBy(css=".dn")
	public WebElement minus;
	
	@FindBy(css="div.rt-price-div > div > label")
	public WebElement price_label;
	
	@FindBy(css="div:nth-child(1) > div:nth-child(1) > a")
	public WebElement Chicken;
	
	@FindBy(css="li[class='error-msg'] ul li span")
	public WebElement successmsg;
	
	@FindBy(css="li[class='error-msg'] ul li span")
	public WebElement errormsg;
	
	@FindBy(className="product-block")
	public List<WebElement> products;
	
	@FindBy(css = "img[src*='fssai-nveg-icon.png']")
	public List<WebElement> productImage;
	
	public By item_prices = By.cssSelector("#cart-sidebar > li.item > div > div > div.qtyinput > span");

	
	public void clickAddToCartBtn() {
		rf.clickElement(addToCartBtn);
	}
	public boolean checkAddToCart() {
		WebDriverWait driverWait = new WebDriverWait(driver, Duration.ofSeconds(15));
		try {
			driverWait.until(d->ajaxcartmsgc.isDisplayed());
			
		} catch (Exception e) {
			System.out.println("inside catch");
			return false;
			
		}
		return true;
	}
	
	public HomePage navigateback() {
		driver.navigate().back();
		return new HomePage(driver);
		
	}
	
	public void click(WebElement element) {
		rf.clickElement(element);
	}
	
	public String getAppliedCouponMessage() {
	    return successmsg.getText();
	}
	
	public String NotvalidCouponMessage() {
	    return errormsg.getText();
	}
	
	public boolean assertTotalSum() {
		List<WebElement> list = driver.findElements(item_prices);
		 double sum=0;
		 for(int i =0;i<list.size();i++)
		 {
			 WebElement ele = list.get(i);
			sum+=Double.parseDouble(ele.getText().replace("₹", ""));
		 }
		 double sub_total = Double.parseDouble(sub_total_price.getText().replace("₹", ""));
		 if(sum==sub_total) {
			 return true;
		 }
		 else {
			 return false;
		 }
	}
	public boolean assertPlusQualityControl() {
		for(int i =1; i< Integer.parseInt(prop.getProperty("plusValue"));i++)
		{
			plus.click();
		}
		String str = quantity.getAttribute("value");
		float count = Float.parseFloat(str);
		String price = price_label.getAttribute("data-product-price");
		float item_price = Float.parseFloat(price);
		float total_price = Float.parseFloat(price_label.getText());
		System.out.println(count);
		System.out.println(item_price);
		System.out.println(total_price);
		if(isEqual(count*item_price,total_price )) {
			for(int i =0; i< Integer.parseInt(prop.getProperty("minusValue"));i++)
			{
			   minus.click();
			}
			String str2 = quantity.getAttribute("value");
			float count2 = Float.parseFloat(str);
			float total_price2 = Float.parseFloat(price_label.getText());
			System.out.println(count);
			System.out.println(item_price);
			System.out.println(total_price);
			if(isEqual(count2 *item_price, total_price)) {
				return true;
			}
			else {
				return false;
			}
		}
		else
		{
			return false;
		}
	}
	
	public void sendText(WebElement element, String text) {
		rf.insertText(text, element);
	}
	
	public boolean isEqual(float a,float b) {
		if(a==b) 
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
	
	public CheckOutPage clickMyCart() {
		click(mycart);
		return new CheckOutPage(driver);
	}
}
