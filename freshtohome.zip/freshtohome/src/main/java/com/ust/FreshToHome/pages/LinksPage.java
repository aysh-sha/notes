package com.ust.FreshToHome.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.FreshToHome.reusables.ReusableFunction;

public class LinksPage {
	public WebDriver driver;
	public ReusableFunction rf;
	public LinksPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		rf = new ReusableFunction(driver);
	}
	
	@FindBy(className="certificates")
	public WebElement certificateImage;
	
	@FindBy(css=".archive-title")
	public WebElement newsroomText;
	
	
	public boolean urlContains(String text) {
		return rf.urlContains(text);
	}
	
	public boolean isDisplayed(WebElement element) {
		return rf.isPresent(element);
		
	}
	public boolean textContains(WebElement el,String txt) {
		return rf.textContains(txt, el);
	}
	

}
