package step_definitions;

import static org.testng.Assert.assertEquals;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.FreshToHome.pages.HomePage;
import com.ust.FreshToHome.pages.ProductPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CouponTest {
	WebDriver driver = Hooks.driver;
	Properties prop = Hooks.properties;
	HomePage homepage;
	ProductPage proudctpage;
	
	private static final Map<String, String> productMapping = new HashMap<>();

    static {
        productMapping.put("product1", "seer fish steaks");
        productMapping.put("product2", "chicken boneless");
    }

    private String getProductFromExample(String productNameFromScenario) {
        return productMapping.get(productNameFromScenario);
    }


	@Given("the user is in the freshtohome homepage")
	public void the_user_is_in_the_freshtohome_homepage() throws InterruptedException {
		homepage = new HomePage(driver);
		homepage.getHomePage();
		homepage.enterLocation();
		
	}

	@When("user serach for a product {string}")
	public void user_serach_for_a_product(String productNameFromScenario) {
		String actualProductName = getProductFromExample(productNameFromScenario);
		proudctpage = new ProductPage(driver);
		homepage.sendText(homepage.Searchfeild, actualProductName);
		proudctpage=homepage.clickProduct(homepage.Searchbutton);
		proudctpage.click(proudctpage.seerfish);
		
	}
	
	@When("adds the product to the cart")
	public void adds_the_product_to_the_cart() {
		//pp.click(pp.quantityincrease);
		proudctpage.click(proudctpage.addToCartBtn);
	}
	
	@When("proceeds to my cart page")
	public void proceeds_to_my_cart_page() {
		
	    proudctpage.click(proudctpage.menu_cart_icon);
	    proudctpage.click(proudctpage.mycart);
	    
	}
	@When("the user applies coupon code {string}")
	public void the_user_applies_coupon_code(String valid) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOf(proudctpage.couponcode));
	    proudctpage.sendText(proudctpage.couponcode, valid);
	    proudctpage.click(proudctpage.apply);
	}
	/*
	 * @Then("the user should see the coupon code specific {string}") public void
	 * the_user_should_see_the_coupon_code_specific(String string) { String
	 * actualMessage = pp.getAppliedCouponMessage(); assertEquals(string,
	 * actualMessage); }
	 */
	@Then("the user should see the coupon code specific {string}")
    public void checkCouponCodeMessage(String messages) {
        System.out.println(messages);
        if (messages.equals("Subtotal should be minimum 1499 to avail this coupon")) {
            the_success_message_should_be_displayed();
        } else if (messages.equals("Subtotal should be minimum 999 to avail this coupon")) {
            the_error_message_should_be_displayed();
        }
    }

    public void the_success_message_should_be_displayed() {
        String actualMessage = proudctpage.getAppliedCouponMessage();
        assertEquals("Subtotal should be minimum 1499 to avail this coupon", actualMessage);
    }

    public void the_error_message_should_be_displayed() {
        String actualMessage = proudctpage.NotvalidCouponMessage();
        assertEquals("Subtotal should be minimum 999 to avail this coupon", actualMessage);
    }
}
	
	


