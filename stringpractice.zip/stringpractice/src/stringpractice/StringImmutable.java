package stringpractice;

public class StringImmutable {


	public static void main(String[] args)
	{
		 String names[] = {"Hello","mohan","jayabalan"};
		 StringImmutable obj = new StringImmutable();
		 obj.joinWords(names);
	}
	private void joinWords(String[] names)
	{
		String sentence ="";
		for(String name : names) {
			
		}
		 
		
	}
}




