package com.ust.FreshToHome.pages;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.FreshToHome.reusables.ReusableFunction;
import com.ust.FreshToHome.utils.ConfigReader;

public class CouponPage {
	public WebDriver driver;
	public Properties prop;
	ReusableFunction rf;
	
	public CouponPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
		prop= ConfigReader.getPropertyValue();
		rf= new ReusableFunction(driver);
	}
	
	@FindBy(xpath="//div[1]/ul[1]/li[1]/a/div[2]/h3")
	public WebElement salmonfish;
	
	@FindBy(css=".odd .button")
	public WebElement addtocart;
	
	@FindBy(css="css=.menu-cart-icon")
	public WebElement addtocarticon;
	
	@FindBy(xpath="//button[@title='Go to Cart Page']")
	public WebElement mycart;
	
	@FindBy(id="coupon_code")
	public WebElement couponcode;
	
	@FindBy(css="btn-yellow")
	public WebElement apply;
	
	
	
	public void sendText(WebElement element, String text) {
		rf.insertText(text, element);
	}
	
	
	
	public void click(WebElement element) {
		rf.clickElement(element);
	}

}
