package stringpractice;

import java.util.Scanner;

public class CharIndex {
	
	
	
	
	
	public static void main (String args[]) {
		Scanner sc = new Scaneer(System.in);
		System.out.println("Enter the string: ");
		String str = sc.nextLine();
	}

}
