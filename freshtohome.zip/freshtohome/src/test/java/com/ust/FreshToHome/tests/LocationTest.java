package com.ust.FreshToHome.tests;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import com.ust.FreshToHome.base.SetUp;
import com.ust.FreshToHome.pages.HomePage;
import com.ust.FreshToHome.pages.LocationPage;

public class LocationTest extends SetUp{
	HomePage homepage;
	LocationPage loc;
	

	
  @Test(priority =0)
  public void loadHomePage() {
	  homepage = new HomePage(driver);
	  homepage.getHomePage();
	  homepage.enterLocation();
	  waits(3000);
	  assertTrue(homepage.checkUrl(properties.getProperty("homePageUrl")),"Failed to load home page");
  }
  
  @Test(priority=1)
  public void selectLocation1(){
	  loc=homepage.clickloc(homepage.locationLinkMangalore);
	  loc= new LocationPage(driver);
	  assertTrue(loc.textContains(loc.Mangaloreloc,properties.getProperty("location1")));
	  
	  
  }
  
  @Test(priority=2)
  public void selectLocation2(){
	  loc=homepage.clickloc(homepage.locationLinkGurgaon);
	  loc= new LocationPage(driver);
	  assertTrue(loc.textContains(loc.gurgoanloc,properties.getProperty("location2")));
	  
	  
  }
  
}
