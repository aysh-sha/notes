package step_definitions;

import static org.testng.Assert.assertTrue;

import java.util.Properties;

import org.openqa.selenium.WebDriver;

import com.ust.FreshToHome.pages.HomePage;
import com.ust.FreshToHome.pages.RefundAndSellerInfoPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SellerTest {
	WebDriver driver = Hooks.driver;
	Properties properties = Hooks.properties;
	HomePage homepage;
	RefundAndSellerInfoPage refundandsellerpage;
	
	@Given("the user in the home page  FreshToHome")
	public void the_user_in_the_home_page_fresh_to_home() {
		homepage = new HomePage(driver);
		homepage.getHomePage();
		homepage.enterLocation();
		assertTrue(homepage.checkUrl(properties.getProperty("homePageUrl")), "Failed to load home page");
	    
	}

	@When("the user clicks on the sellers link")
	public void the_user_clicks_on_the_sellers_link() {
		refundandsellerpage = new RefundAndSellerInfoPage(driver);
		homepage.click(homepage.sellers);
	    
	}
	@Then("the user should be redirected to the seller's information page")
	public void the_user_should_be_redirected_to_the_seller_s_information_page() {
		assertTrue(refundandsellerpage.textContains(refundandsellerpage.sellertext,properties.getProperty("Seller")),"Failed to dispaly Refund details");
	}
	

}
