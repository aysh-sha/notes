package com.ust.FreshToHome.pages;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.FreshToHome.reusables.ReusableFunction;
import com.ust.FreshToHome.utils.ConfigReader;

public class FSSAIPage {
	public WebDriver driver;
	public Properties prop;
	ReusableFunction rf;
	
	public FSSAIPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver,this);
		prop= ConfigReader.getPropertyValue();
		rf = new ReusableFunction(driver);
	}
	
	
	
	@FindBy(xpath="//div[@class='products-wrapper']/div[1]/ul[1]/li[1]/a[1]")
	public WebElement cutlet;
	
	@FindBy (xpath="//div[8]/div/p[2]/b")
	public WebElement fssainumber;
	
	public void click(WebElement element) {
		rf.clickElement(element);
	}
	public boolean textContains(WebElement el,String txt) {
		return rf.textContains(txt, el);
	}
}
