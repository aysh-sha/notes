package com.ust.FreshToHome.pages;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.FreshToHome.reusables.ReusableFunction;

public class FishAndSeafoodPage {
	public WebDriver driver;
	public Properties prop;
	ReusableFunction rf;
	

	public FishAndSeafoodPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
		rf = new ReusableFunction(driver);
	}
	
	@FindBy(linkText="Poultry")
	public WebElement poultryLink;
	
	@FindBy(css="div[class='products-wrapper'] h2:nth-child(1)")
	public WebElement validateResultofFishPage;
	
	public PoultryPage clickPoultryLink(WebElement el) {
		rf.clickElement(el);
		return new PoultryPage(driver);
	}
	
	public boolean textContains(WebElement el,String txt) {
		return rf.textContains(txt, el);
	}
	
	

}
