package com.ust.FreshToHome.tests;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import com.ust.FreshToHome.base.SetUp;
import com.ust.FreshToHome.pages.HomePage;
import com.ust.FreshToHome.pages.LinksPage;

public class LinkTest extends SetUp{
	
	HomePage homepage;
	LinksPage linkpage =new LinksPage(driver);;
	
	@Test(priority=0)
	public void loadHomePage() {
		homepage = new HomePage(driver);
		homepage.getHomePage();
		homepage.enterLocation();
		assertTrue(homepage.checkUrl(properties.getProperty("homePageUrl")),"Failed to load home page");
		
	}
	
	@Test(priority = 1)
	public void test_certificate_link() {
		linkpage = homepage.clickLink(homepage.certificatesLink);
		assertTrue(linkpage.isDisplayed(linkpage.certificateImage),"Failed to validate Certificate Page");
	}
	
	@Test(priority = 2)
	public void test_why_us_link() {
		linkpage = homepage.clickLink(homepage.whyUsLink);
		assertTrue(linkpage.urlContains(properties.getProperty("whyUsResult")),"Failed To validate 'Why Us' page");
	}
	
	@Test(priority = 3)
	public void test_newsroom_link() {
		linkpage=homepage.clickLink(homepage.newsroomLink);
		assertTrue(linkpage.urlContains(properties.getProperty("NewroomResult")),"Failed to validate 'Newsroom' link ");
		driver.navigate().back();
	}
	
	@Test(priority = 4)
	public void test_sell_with_us_link() {
		linkpage=homepage.clickLink(homepage.sellWithUsLink);
		assertTrue(linkpage.urlContains(properties.getProperty("SellWithUsLink")),"Failed To validate 'Sell With Us' page");
		
	}
	

}
