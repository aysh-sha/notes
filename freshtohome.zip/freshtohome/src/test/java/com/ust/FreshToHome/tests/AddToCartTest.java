package com.ust.FreshToHome.tests;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.awt.RenderingHints.Key;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.FreshToHome.pages.HomePage;
import com.ust.FreshToHome.pages.ProductPage;
import com.ust.FreshToHome.base.SetUp;

import com.ust.FreshToHome.utils.ExtentReportsListener;

@Listeners(ExtentReportsListener.class)
public class AddToCartTest extends SetUp {
	HomePage homePage;
    ProductPage productpage;

    @Test(priority=0)
 	public void testEmptyCart() {
    	homePage = new HomePage(driver);
 		homePage.getHomePage();
		homePage.enterLocation();
 		assertEquals(homePage.getCartMessage(),homePage.getCartEmptyMessage());
 	}
    
    @Test(priority=1)
	public void addToCart() throws InterruptedException {
		homePage.getHomePage();
		productpage = homePage.clickProduct(homePage.product1);
		productpage.clickAddToCartBtn();
		assertTrue(productpage.checkAddToCart());
	}
	@Test(priority = 2)
	public void checkSubtotal() throws InterruptedException {
		homePage.getHomePage();
		productpage = homePage.clickProduct(homePage.product1);
		productpage.clickAddToCartBtn();
		assertTrue(productpage.checkAddToCart());
		homePage = productpage.navigateback();
		productpage = homePage.clickProduct(homePage.product2);
		productpage.clickAddToCartBtn();
		assertTrue(productpage.checkAddToCart());
		productpage.click(productpage.menu_cart_icon);
		assertTrue(productpage.assertTotalSum());
	}
	@Test(priority=3)
	public void testQuantityControl() throws InterruptedException {
		homePage.getHomePage();
		productpage = homePage.clickProduct(homePage.product1);
		productpage.assertPlusQualityControl();
		
	}
    

}
