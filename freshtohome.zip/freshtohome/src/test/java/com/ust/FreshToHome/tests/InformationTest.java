package com.ust.FreshToHome.tests;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import com.ust.FreshToHome.base.SetUp;
import com.ust.FreshToHome.pages.FSSAIPage;
import com.ust.FreshToHome.pages.HomePage;
import com.ust.FreshToHome.pages.InformationPage;

public class InformationTest extends SetUp {
		HomePage homepage;
		InformationPage ip;;
		
	  @Test(priority=0)
	  public void loadHomePage() {
		  homepage = new HomePage(driver);
		  homepage.getHomePage();
		  homepage.enterLocation();
		  assertTrue(homepage.checkUrl(properties.getProperty("homePageUrl")),"Falied to load homepage");
		  
	  }
	  
	  @Test(priority=1)
	  public void checkRefundPolicy() {
		  ip=homepage.clickInfo(homepage.refundpolicy);
		  ip = new InformationPage(driver);
		  assertTrue(ip.textContains(ip.refundpolicytext,properties.getProperty("Refundpolicy")),"Failed to display refund policy");
		  driver.navigate().back();
	  
	  }
	  
	  @Test(priority=2)
	  public void checkSellersInfo() {
		  ip=homepage.clickInfo(homepage.sellers);
		  ip = new InformationPage(driver);
		  assertTrue(ip.textContains(ip.sellerstext,properties.getProperty("Sellers")),"Failed to dispaly Sellers details");
		  }
}