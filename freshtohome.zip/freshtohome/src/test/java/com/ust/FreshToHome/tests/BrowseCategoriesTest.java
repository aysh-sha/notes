package com.ust.FreshToHome.tests;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import com.ust.FreshToHome.base.SetUp;
import com.ust.FreshToHome.pages.FishAndSeafoodPage;
import com.ust.FreshToHome.pages.HomePage;
import com.ust.FreshToHome.pages.MuttonPage;
import com.ust.FreshToHome.pages.PoultryPage;
import com.ust.FreshToHome.pages.ReadyToCookPage;
import com.ust.FreshToHome.pages.SteaksFilletPage;


public class BrowseCategoriesTest extends SetUp{
	
	HomePage homepage;
	FishAndSeafoodPage fs;
	PoultryPage pp;
	MuttonPage mp;
	SteaksFilletPage sfp;
	ReadyToCookPage rp;
	
	
	@Test(priority = 0)
	public void loadHomePage() {
		homepage = new HomePage(driver);
		homepage.getHomePage();
		homepage.enterLocation();
		assertTrue(homepage.checkUrl(properties.getProperty("homePageUrl")),"Failed to load home page");
		
	}
	
	@Test(priority=1)
	public void test_fish_and_seafood_link() {
		
		fs=homepage.clickFishandSeafoodLink(homepage.FishAndSeafood_link);
		fs=new FishAndSeafoodPage(driver);
		assertTrue(fs.textContains(fs.validateResultofFishPage, properties.getProperty("FishResults")));
	}
	
	@Test(priority=2)
	public void test_poultry_link() {
		pp=fs.clickPoultryLink(fs.poultryLink);
		pp=new PoultryPage(driver);
		assertTrue(pp.textContains(pp.validateResultofPoultryPage, properties.getProperty("PoultryResult")));
		
	}
	
	@Test(priority = 3)
	public void test_mutton_link() {
		mp=pp.clickMuttonLink(pp.muttonPagelink);
		mp=new MuttonPage(driver);
		assertTrue(mp.textContains(mp.validateResultofMuttonPage,properties.getProperty("MuttonResult")));
	}
	
	@Test(priority = 4)
	public void test_steak_and_fillet_link() {
		sfp=mp.clickSteaksFilletlink(mp.steaksFilletLink);
		sfp=new SteaksFilletPage(driver);
		assertTrue(sfp.textContains(sfp.validateResultofSteaksPage, properties.getProperty("SteakResult")));
		
	}
	
	@Test(priority = 5)
	public void test_ready_to_cook_link() {
		rp=sfp.clickReadyToCooklink(sfp.readyToCookLink);
		rp=new ReadyToCookPage(driver);
		assertTrue(rp.textContains(rp.validateResultofReadyToCookPage,properties.getProperty("ReadyToCookResult")));
		
	}
	
	/*
	 * @Test(priority=6) public void test_if_all_categories_are_present() {
	 * //List<WebElement> categories = }
	 */
	
	
	
	
	
	
	
	
	

}
