package step_definitions;

import static org.testng.Assert.assertTrue;

import java.util.List;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ust.FreshToHome.pages.HomePage;
import com.ust.FreshToHome.pages.ProductPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class VegNonVegTest {
	WebDriver driver = Hooks.driver;
	Properties properties = Hooks.properties;
	HomePage homepage;
	ProductPage productpage;

	@Given("the user in the page where products are listed")
	public void the_user_in_the_page_where_products_are_listed() {
		homepage = new HomePage(driver);
		homepage.getHomePage();
		homepage.enterLocation();
	}

	@Then("user should be able to see a non-veg or veg symbol on each product image")
	public void user_should_be_able_to_see_a_non_veg_or_veg_symbol_on_each_product_image() {
		productpage = new ProductPage(driver);
		List<WebElement> productImages = productpage.productImage;
		for (WebElement image : productImages) {

			String srcValue = image.getAttribute("src");

			if (srcValue != null
					&& (srcValue.contains("veg-icon")
							|| srcValue.contains("nveg-icon"))) {
				//System.out.println("Icon is displayed");
				assertTrue(true);
				
			} else {
				assertTrue(false);
			}
		}
	}

}
