package com.ust.FreshToHome.pages;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.FreshToHome.reusables.ReusableFunction;

public class PoultryPage {
	public WebDriver driver;
	public Properties prop;
	ReusableFunction rf;
	
	public PoultryPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
		rf = new ReusableFunction(driver);
	}
	
	@FindBy(linkText="Mutton")
	public WebElement muttonPagelink;
	
	@FindBy(css=".category-header")
	public WebElement validateResultofPoultryPage;
	
	public MuttonPage clickMuttonLink(WebElement el) {
		rf.clickElement(el);
		return new MuttonPage(driver);
	}
	public boolean textContains(WebElement el,String txt) {
		return rf.textContains(txt, el);
	}

}
