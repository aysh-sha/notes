package step_definitions;

import static org.testng.Assert.assertTrue;

import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.ust.FreshToHome.pages.HomePage;
import com.ust.FreshToHome.pages.ProductPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class ProductImageTest {
	WebDriver driver = Hooks.driver;
	Properties properties = Hooks.properties;
	HomePage homepage;
	ProductPage productpage;

	@Given("the user in the home page")
	public void the_user_in_the_home_page() {
		homepage = new HomePage(driver);
		homepage.getHomePage();
		homepage.enterLocation();
	}

	@Then("each product displayed should have an image.")
	public void each_product_displayed_should_have_an_image() {
		productpage = new ProductPage(driver);
		List<WebElement> productContainers = productpage.products;
		for (WebElement productContainer : productContainers) {

			List<WebElement> images = productContainer.findElements(By.tagName("img"));
			if (images.isEmpty()) {

				assertTrue(false);
			} else {
				assertTrue(true);
			}
		}
	}

}
