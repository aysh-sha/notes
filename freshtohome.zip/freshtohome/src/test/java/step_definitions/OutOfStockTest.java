package step_definitions;

import static org.testng.Assert.assertTrue;

import java.util.Properties;

import org.openqa.selenium.WebDriver;

import com.ust.FreshToHome.pages.HomePage;
import com.ust.FreshToHome.pages.SearchPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;


public class OutOfStockTest {
	
	WebDriver driver = Hooks.driver;
	Properties properties = Hooks.properties;
	HomePage homepage;
	SearchPage searchpage;
	
	@Given("the user in the FreshToHome home page")
	public void the_user_in_the_fresh_to_home_home_page() {
		homepage = new HomePage(driver);
		homepage.getHomePage();
		homepage.enterLocation();
		assertTrue(homepage.checkUrl(properties.getProperty("homePageUrl")), "Failed to load home page");
	    
	}
	
	@Given("the user searches for a product")
	public void the_user_searches_for_a_product() {
		homepage.sendText(homepage.Searchfeild, properties.getProperty("OutOfStock"));  
	}
	
	@Given("the user clicks the search button")
	public void the_user_clicks_the_search_button() {
	   searchpage = homepage.clickSearch(homepage.Searchbutton);
	   searchpage = new SearchPage(driver);
	}
	

	@Then("the out of stock message has to be displayed with the product")
	public void the_out_of_stock_message_has_to_be_displayed_with_the_product() {
	   assertTrue(searchpage.isDisplayed(searchpage.outOfStock));
	}

	@Given("the user clicks on the product")
	public void the_user_clicks_on_the_product() {
	    searchpage.click(searchpage.outOfStockProduct);
	}
	@Then("the Add to Cart button should not be available")
	public void the_add_to_cart_button_should_not_be_available() {
	    assertTrue(searchpage.isNotPresent(searchpage.addToCartBtn));
	}
	


}
