package com.ust.FreshToHome.pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.FreshToHome.reusables.ReusableFunction;
import com.ust.FreshToHome.utils.ConfigReader;

public class CheckOutPage {
	public WebDriver driver;
	public Properties properties;
	public ReusableFunction rf;

	public CheckOutPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		properties = ConfigReader.getPropertyValue();
		rf = new ReusableFunction(driver);
	}
	
	@FindBy(css=".first .up")
	public WebElement plusQuantity;
	
	@FindBy(css = ".first > .a-right:nth-child(4) .price")
	public WebElement price;
	
	@FindBy(css = "td:nth-child(6) > .cart-price > span")
	public WebElement priceElement;
	
	@FindBy(css = " button.button.btn-update > span > span")
	public WebElement updateCartBtn;
	
	@FindBy(css = ".review_subtotal > td:nth-child(2) > span")
	public WebElement review_subtotal;
	
	@FindBy(css = "td:nth-child(6) > .cart-price > span")
	public WebElement item_subtotal_ele;
	
	@FindBy(css = ".btn-remove.btn-remove")
	public WebElement delete_btn;
	
	@FindBy(css = ".cart-empty > p:nth-child(1)")
	public WebElement cart_msg_ele;
	
	@FindBy(id = "empty_cart_button")
	public WebElement empty_cart_button;
	
	public void click(WebElement element) {
		rf.clickElement(element);
	}
	
	public String getActualUrl() {
		return driver.getCurrentUrl();
	}
	
	public String getExpectedUrl() {
		return properties.getProperty("checkOutPageUrl");
	}
	
	public double getPriceValue(WebElement ele) {
		double price = Double.parseDouble(ele.getText().replace("₹", ""));
		return price;
	}
	
	public boolean checkUpdateCart() {
		  click(plusQuantity);
		  double item_price = Double.parseDouble(price.getText().replace("₹", ""));
		  double cal_item_subtotal = 2 * item_price;
		  double item_subtotal = Double.parseDouble(item_subtotal_ele.getText().replace("₹", ""));
		  click(updateCartBtn);
		  double review_price = getPriceValue(review_subtotal);
		  System.out.println(review_price);
		  if(cal_item_subtotal == item_subtotal && item_subtotal == review_price) {
			  return true;
		  }
		  else {
			  return false;
		  }
	}

	public void deleteItem() {
		click(delete_btn);
		
	}
	
	public String getEmptyCartMsg() {
		return properties.getProperty("emptyCartMessage");
	}
	public String getCartMsg() {
		return cart_msg_ele.getText();
	}
}
