package com.ust.FreshToHome.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.ust.FreshToHome.reusables.ReusableFunction;

public class SocialMediaPage {
	public WebDriver driver;
	public ReusableFunction rf;
	
	public SocialMediaPage (WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
		rf = new ReusableFunction(driver);
	}
	
	public boolean urlContains(String text) {
		return rf.urlContains(text);
	}

}
