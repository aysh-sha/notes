package com.ust.FreshToHome.tests;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import com.ust.FreshToHome.base.SetUp;
import com.ust.FreshToHome.pages.HomePage;

public class ContactTest extends SetUp {
	HomePage homepage;
  @Test(priority=0)
  public void loadHomepPage() {
	  homepage = new HomePage(driver);
	  homepage.getHomePage();
	  homepage.enterLocation();
	  assertTrue(homepage.checkUrl(properties.getProperty("homePageUrl")),"Failed to load home page");
	  
  }
  
  @Test(priority=1)
  public void checkContactDetails() {
	  assertTrue(homepage.isDisplayed(homepage.contactNumber),"Failed to validate Contact Number");
	  assertTrue(homepage.isDisplayed(homepage.contactEmail),"Failed to validate Email");
	  
  }
  
}
