package com.ust.FreshToHome.pages;

import java.util.Properties;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.FreshToHome.reusables.ReusableFunction;
import com.ust.FreshToHome.utils.ConfigReader;

public class HomePage {
	public WebDriver driver;
	public Properties prop;
	public ReusableFunction rf;

	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		prop = ConfigReader.getPropertyValue();
		rf = new ReusableFunction(driver);
	}

	@FindBy(linkText = "Fish & Seafood")
	public WebElement FishAndSeafood_link;

	@FindBy(id = "search")
	public WebElement Searchfeild;

	@FindBy(xpath = "//button[@title='Search']/span[1]")
	public WebElement Searchbutton;

	@FindBy(css = ".menu-cart-icon")
	public WebElement cartIcon;

	@FindBy(linkText = "JOIN NOW")
	public WebElement joinNowLink;

	@FindBy(className = "facebook")
	public WebElement facebookLink;

	@FindBy(className = "twitter")
	public WebElement twitterLink;

	@FindBy(className = "instagram")
	public WebElement instagramLink;

	@FindBy(className = "youtube")
	public WebElement youtubeLink;

	@FindBy(linkText = "Certificates")
	public WebElement certificatesLink;

	@FindBy(linkText = "Why us")
	public WebElement whyUsLink;

	@FindBy(linkText = "Newsroom")
	public WebElement newsroomLink;

	@FindBy(linkText = "Sell-With-Us")
	public WebElement sellWithUsLink;

	@FindBy(css = ".left.numbers")
	public WebElement contactNumber;

	@FindBy(css = "div[class='left email']")
	public WebElement contactEmail;

	@FindBy(linkText = "Gurgaon")
	public WebElement locationLinkGurgaon;

	@FindBy(linkText = "Mangalore")
	public WebElement locationLinkMangalore;

	@FindBy(id = "autoComplete")
	public WebElement autoComplete;
	
	@FindBy(css="div:nth-child(8) > div > ul > li.item.first.col-xs-3.w-20 > a")
	public WebElement product1;
	
	@FindBy(css="div.std > div:nth-child(8) > div > ul > li:nth-child(3) > a")
	public WebElement product2;

	@FindBy(css = "div:nth-child(8) > div > ul > li.item.first.col-xs-3.w-20 > a")
	public WebElement product;

	@FindBy(linkText = "Ready to Cook")
	public WebElement productready;

	@FindBy(linkText = "Refund Policy")
	public WebElement refundpolicy;

	@FindBy(linkText = "Sellers")
	public WebElement sellers;
	
	@FindBy(linkText="JOIN NOW")
	public WebElement vipjoin;
	
	@FindBy(className = "menu-cart-icon")
	public WebElement menu_cart_icon;
	
	@FindBy(css  = ".empty")
	public WebElement empty;
	
	public void getHomePage() {
		driver.get(prop.getProperty("homePageUrl"));
	}

	public SearchPage clickSearch(WebElement element) {
		rf.clickElement(element);
		return new SearchPage(driver);
	}

	public boolean checkUrl(String url) {
		return rf.checkurl(url);
	}

	public FishAndSeafoodPage clickFishandSeafoodLink(WebElement element) {
		rf.clickElement(element);
		return new FishAndSeafoodPage(driver);
	}

	public void click(WebElement element) {
		rf.clickElement(element);
	}

	public void sendText(WebElement element, String text) {
		rf.insertText(text, element);
	}

	public void enterLocation() {
		autoComplete.sendKeys(prop.getProperty("pincode") + Keys.ENTER);
	}

	public LocationPage clickloc(WebElement element) {
		rf.clickElement(element);
		return new LocationPage(driver);
	}

	public ProductPage clickProduct(WebElement product) {
		rf.clickElement(product);
		return new ProductPage(driver);
	}

	public LinksPage clickLink(WebElement element) {
		rf.clickElement(element);
		return new LinksPage(driver);

	}

	public FSSAIPage clickReadyToCook(WebElement element) {
		rf.clickElement(element);
		return new FSSAIPage(driver);
	}

	public InformationPage clickInfo(WebElement element) {
		rf.clickElement(element);
		return new InformationPage(driver);
	}
	
	public RefundAndSellerInfoPage clickrefundandseller(WebElement element) {
		rf.clickElement(element);
		return new RefundAndSellerInfoPage(driver);
	}

	public boolean isDisplayed(WebElement element) {
		return rf.isPresent(element);
	}

	public void windowTabHandle() {
		rf.windowTabHandle();

	}

	public void windowTabHandlezero() {
		rf.windowTabHandlezero();

	}

	public void closeWindowTab() {
		rf.closeWindowTab();
	}

	public SocialMediaPage clickSocialMediaLinks(WebElement el) {
		rf.clickElement(el);
		return new SocialMediaPage(driver);

	}
	
	public CouponPage clickcoupon(WebElement element) {
		rf.clickElement(element);
		return new CouponPage(driver);
	}
	
	public String getCartMessage() {
		String cart_msg;
		click(menu_cart_icon);
		cart_msg = empty.getText();
		return cart_msg;
	}

	public String getCartEmptyMessage() {
		return prop.getProperty("emptyCartMessage");
	}
}
