package com.ust.FreshToHome.tests;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ust.FreshToHome.base.SetUp;
import com.ust.FreshToHome.pages.HomePage;
import com.ust.FreshToHome.pages.SearchPage;
import com.ust.FreshToHome.utils.ExcelDataReader;

public class SpicesAndIngredientsTest {
  @Test
  public class SearchTest extends SetUp {
		HomePage homepage;
		SearchPage searchpage;

		@Test(priority = 0)
		public void loadHomePage() throws InterruptedException {
			homepage = new HomePage(driver);
			homepage.getHomePage();
			homepage.enterLocation();
			assertTrue(homepage.checkUrl(properties.getProperty("homePageUrl")), "Failed to load home page");
		}
	  
		@Test(priority = 1,dataProvider="product")
		public void searchProduct(String text) {
			homepage.sendText(homepage.Searchfeild, text);
			searchpage=homepage.clickSearch(homepage.Searchbutton);
			searchpage= new SearchPage(driver);
			waits(2000);
			searchpage.click(searchpage.butterchicken);
			//driver.navigate().back();
	       
	       
		}
		
		@Test(priority=2)
		public void checkSpices() {
			 assertTrue(searchpage.isDisplayed(searchpage.spices));
		}
		@Test(priority=3)
		public void checkIngredients() {
			assertTrue(searchpage.textContains(properties.getProperty("Ingredients"),searchpage.ingredients));
		}
		
		
  
  
  @DataProvider(name = "product")
	public String[][] input() throws IOException {

		String path = System.getProperty("user.dir") + "\\src\\test\\resources\\DataSource\\Data.xlsx";
		String Sheetname = "Sheet3";
		String[][] data = ExcelDataReader.readDataFromSheet(Sheetname, path);

		return data;

	}
}
}
