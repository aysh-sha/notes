package step_definitions;

import static org.testng.Assert.assertTrue;

import java.util.Properties;

import org.openqa.selenium.WebDriver;

import com.ust.FreshToHome.pages.HomePage;
import com.ust.FreshToHome.pages.InformationPage;
import com.ust.FreshToHome.pages.RefundAndSellerInfoPage;
import com.ust.FreshToHome.pages.SearchPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class RefundPolicyTest {
	
	WebDriver driver = Hooks.driver;
	Properties properties = Hooks.properties;
	HomePage homepage;
	RefundAndSellerInfoPage refundandsellerpage;
	
	@Given("the user in the home page Freshtohome")
	public void the_user_in_the_home_page_Freshtohome() {
		homepage = new HomePage(driver);
		homepage.getHomePage();
		homepage.enterLocation();
		assertTrue(homepage.checkUrl(properties.getProperty("homePageUrl")), "Failed to load home page");
	    
	}

	@When("the user clicks on the Refund Policy link")
	public void the_user_clicks_on_the_refund_policy_link() {
		refundandsellerpage = new RefundAndSellerInfoPage(driver);
		homepage.click(homepage.refundpolicy);
	    
	}
	
	@Then("the user should see details about the refund policy")
	public void the_user_should_see_details_about_the_refund_policy() {
		assertTrue(refundandsellerpage.textContains(refundandsellerpage.refundtext,properties.getProperty("Refund")),"Failed to dispaly Refund details");
	    
	}


	

}
